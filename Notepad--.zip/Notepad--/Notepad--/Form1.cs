using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Notepad__
{
    public partial class Form1 : Form
    {
        #region VARI�VEIS
        // Vari�vel global deste projeto que cont�m o nome do documento
        private string ficheiro = "";
        #endregion

        #region FUN��ES
        private void GuardarFicheiro()
        {
            // Configura��o da janela de Di�logo Guardar
            saveFileDialog1.Filter = "Ficheiros RTF | *.rtf | Ficheiros TXT | *.txt";
            saveFileDialog1.FileName = "";

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // Grava��o do conte�do do ficheiro
                ficheiro = saveFileDialog1.FileName;
                rbTexto.SaveFile(ficheiro);
                rbTexto.Modified = false;
            }
        }

        private void VerificaAlteracoes()
        {
            if (rbTexto.Modified == true)
            {
                DialogResult resposta = MessageBox.Show("Deseja guardar o texto atual?", "Aten��o", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (resposta == DialogResult.Yes)
                {
                    if (ficheiro != "")
                    {
                        rbTexto.SaveFile(ficheiro);
                        rbTexto.Modified = false;
                    }
                    else
                    {
                        GuardarFicheiro();
                    }
                }
            }
        }
        #endregion

        #region EVENTOS
        public Form1()
        {
            InitializeComponent();
        }

        private void menuFicheiroNovo_Click(object sender, EventArgs e)
        {
            VerificaAlteracoes();

            rbTexto.ResetText();
            rbTexto.Modified = false;
            ficheiro = null;
        }

        private void menuFicheiroAbrir_Click(object sender, EventArgs e)
        {
            VerificaAlteracoes();

            // Configura��o da caixa de di�logo de abrir
            openFileDialog1.Filter = "Ficheiros RTF| *.rtf | Ficheiros TXT| *.txt | Todos | *.*";
            openFileDialog1.FileName = "";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // Abre o ficheiro selecionado
                ficheiro = openFileDialog1.FileName;
                rbTexto.LoadFile(ficheiro);
                rbTexto.Modified = false;
            }
        }

        private void menuFicheiroGuardar_Click(object sender, EventArgs e)
        {
            if (ficheiro != "")
            {
                rbTexto.SaveFile(ficheiro);
                rbTexto.Modified = false;
            }
            else
            {
                GuardarFicheiro();
            }
        }

        private void menuFicheiroSair_Click(object sender, EventArgs e)
        {
            DialogResult resposta = MessageBox.Show("Deseja sair da aplica��o?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resposta == DialogResult.Yes)
                VerificaAlteracoes();
        }

        private void rbTexto_TextChanged(object sender, EventArgs e)
        {

        }

        private void menuEditarCopiar_Click(object sender, EventArgs e)
        {
            // Copia o texto para a mem�ria RAM do computador
            rbTexto.Copy();
        }

        private void menuEditarCortar_Click(object sender, EventArgs e)
        {
            // Corta o texto selecionado
            rbTexto.Cut();
        }

        private void menuEditarColar_Click(object sender, EventArgs e)
        {
            // Cola o texto na mem�ria RAM do computador para a RB
            rbTexto.Paste();
        }

        private void menuEditarSelecionarTudo_Click(object sender, EventArgs e)
        {
            // Seleciona o texto todo na rb
            rbTexto.SelectAll();
        }

        private void menuEditarProcurar_Click(object sender, EventArgs e)
        {
            string txtProcura = Interaction.InputBox("Digite o que procura:", "Procurar", "", 150, 200);

            int resultado = rbTexto.Find(txtProcura);
            if (resultado == -1)
                MessageBox.Show("N�o foi encontrada a sua procura.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void menuFormatarLetra_Click(object sender, EventArgs e)
        {
            if (rbTexto.SelectionFont != null)
                fontDialog1.Font = rbTexto.SelectionFont;
            else
            {
                fontDialog1.Font = null;
            }

            fontDialog1.ShowDialog();
            rbTexto.SelectionFont = fontDialog1.Font;
        }

        private void menuFormatarCores_Click(object sender, EventArgs e)
        {

        }

        private void menuFormatarCoresFundo_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            rbTexto.SelectionBackColor = colorDialog1.Color;
        }

        private void menuFormatarCoresLetra_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            rbTexto.SelectionColor = colorDialog1.Color;
        }

        private void menuFormatarAlinhamentoEsquerda_Click(object sender, EventArgs e)
        {
            rbTexto.SelectionAlignment = HorizontalAlignment.Left;
        }

        private void menuFormatarAlinhamentoCentro_Click(object sender, EventArgs e)
        {
            rbTexto.SelectionAlignment = HorizontalAlignment.Center;
        }

        private void menuFormatarAlinhamentoDireita_Click(object sender, EventArgs e)
        {
            rbTexto.SelectionAlignment = HorizontalAlignment.Right;
        }
    }
    #endregion
}
