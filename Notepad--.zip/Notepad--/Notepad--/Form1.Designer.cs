﻿namespace Notepad__
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            toolStrip1 = new ToolStrip();
            menuFicheiro = new ToolStripSplitButton();
            menuFicheiroNovo = new ToolStripMenuItem();
            menuFicheiroAbrir = new ToolStripMenuItem();
            menuFicheiroGuardar = new ToolStripMenuItem();
            menuFicheiroSair = new ToolStripMenuItem();
            toolStripSplitButton2 = new ToolStripSplitButton();
            menuEditarCortar = new ToolStripMenuItem();
            menuEditarCopiar = new ToolStripMenuItem();
            menuEditarColar = new ToolStripMenuItem();
            menuEditarSelecionarTudo = new ToolStripMenuItem();
            menuEditarProcurar = new ToolStripMenuItem();
            toolStripSplitButton3 = new ToolStripSplitButton();
            menuFormatarLetra = new ToolStripMenuItem();
            menuFormatarCores = new ToolStripMenuItem();
            menuFormatarCoresLetra = new ToolStripMenuItem();
            menuFormatarCoresFundo = new ToolStripMenuItem();
            menuFormatarAlinhamento = new ToolStripMenuItem();
            menuFormatarAlinhamentoEsquerda = new ToolStripMenuItem();
            menuFormatarAlinhamentoCentro = new ToolStripMenuItem();
            menuFormatarAlinhamentoDireita = new ToolStripMenuItem();
            rbTexto = new RichTextBox();
            fontDialog1 = new FontDialog();
            colorDialog1 = new ColorDialog();
            openFileDialog1 = new OpenFileDialog();
            saveFileDialog1 = new SaveFileDialog();
            statusStrip1 = new StatusStrip();
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // toolStrip1
            // 
            toolStrip1.ImageScalingSize = new Size(30, 30);
            toolStrip1.Items.AddRange(new ToolStripItem[] { menuFicheiro, toolStripSplitButton2, toolStripSplitButton3 });
            toolStrip1.Location = new Point(0, 0);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Size = new Size(800, 25);
            toolStrip1.TabIndex = 0;
            toolStrip1.Text = "toolStrip1";
            // 
            // menuFicheiro
            // 
            menuFicheiro.DropDownItems.AddRange(new ToolStripItem[] { menuFicheiroNovo, menuFicheiroAbrir, menuFicheiroGuardar, menuFicheiroSair });
            menuFicheiro.ImageTransparentColor = Color.Magenta;
            menuFicheiro.Name = "menuFicheiro";
            menuFicheiro.Size = new Size(65, 22);
            menuFicheiro.Text = "Ficheiro";
            // 
            // menuFicheiroNovo
            // 
            menuFicheiroNovo.Name = "menuFicheiroNovo";
            menuFicheiroNovo.Size = new Size(180, 22);
            menuFicheiroNovo.Text = "Novo";
            menuFicheiroNovo.Click += menuFicheiroNovo_Click;
            // 
            // menuFicheiroAbrir
            // 
            menuFicheiroAbrir.Name = "menuFicheiroAbrir";
            menuFicheiroAbrir.Size = new Size(180, 22);
            menuFicheiroAbrir.Text = "Abrir";
            menuFicheiroAbrir.Click += menuFicheiroAbrir_Click;
            // 
            // menuFicheiroGuardar
            // 
            menuFicheiroGuardar.Name = "menuFicheiroGuardar";
            menuFicheiroGuardar.Size = new Size(180, 22);
            menuFicheiroGuardar.Text = "Guardar";
            menuFicheiroGuardar.Click += menuFicheiroGuardar_Click;
            // 
            // menuFicheiroSair
            // 
            menuFicheiroSair.Name = "menuFicheiroSair";
            menuFicheiroSair.Size = new Size(180, 22);
            menuFicheiroSair.Text = "Sair";
            menuFicheiroSair.Click += menuFicheiroSair_Click;
            // 
            // toolStripSplitButton2
            // 
            toolStripSplitButton2.DropDownItems.AddRange(new ToolStripItem[] { menuEditarCortar, menuEditarCopiar, menuEditarColar, menuEditarSelecionarTudo, menuEditarProcurar });
            toolStripSplitButton2.ImageTransparentColor = Color.Magenta;
            toolStripSplitButton2.Name = "toolStripSplitButton2";
            toolStripSplitButton2.Size = new Size(53, 22);
            toolStripSplitButton2.Text = "Editar";
            // 
            // menuEditarCortar
            // 
            menuEditarCortar.Name = "menuEditarCortar";
            menuEditarCortar.Size = new Size(156, 22);
            menuEditarCortar.Text = "Cortar";
            menuEditarCortar.Click += menuEditarCortar_Click;
            // 
            // menuEditarCopiar
            // 
            menuEditarCopiar.Name = "menuEditarCopiar";
            menuEditarCopiar.Size = new Size(156, 22);
            menuEditarCopiar.Text = "Copiar";
            menuEditarCopiar.Click += menuEditarCopiar_Click;
            // 
            // menuEditarColar
            // 
            menuEditarColar.Name = "menuEditarColar";
            menuEditarColar.Size = new Size(156, 22);
            menuEditarColar.Text = "Colar";
            menuEditarColar.Click += menuEditarColar_Click;
            // 
            // menuEditarSelecionarTudo
            // 
            menuEditarSelecionarTudo.Name = "menuEditarSelecionarTudo";
            menuEditarSelecionarTudo.Size = new Size(156, 22);
            menuEditarSelecionarTudo.Text = "Selecionar tudo";
            menuEditarSelecionarTudo.Click += menuEditarSelecionarTudo_Click;
            // 
            // menuEditarProcurar
            // 
            menuEditarProcurar.Name = "menuEditarProcurar";
            menuEditarProcurar.Size = new Size(156, 22);
            menuEditarProcurar.Text = "Procurar";
            menuEditarProcurar.Click += menuEditarProcurar_Click;
            // 
            // toolStripSplitButton3
            // 
            toolStripSplitButton3.DropDownItems.AddRange(new ToolStripItem[] { menuFormatarLetra, menuFormatarCores, menuFormatarAlinhamento });
            toolStripSplitButton3.ImageTransparentColor = Color.Magenta;
            toolStripSplitButton3.Name = "toolStripSplitButton3";
            toolStripSplitButton3.Size = new Size(71, 22);
            toolStripSplitButton3.Text = "Formatar";
            // 
            // menuFormatarLetra
            // 
            menuFormatarLetra.Name = "menuFormatarLetra";
            menuFormatarLetra.Size = new Size(143, 22);
            menuFormatarLetra.Text = "Letra";
            menuFormatarLetra.Click += menuFormatarLetra_Click;
            // 
            // menuFormatarCores
            // 
            menuFormatarCores.DropDownItems.AddRange(new ToolStripItem[] { menuFormatarCoresLetra, menuFormatarCoresFundo });
            menuFormatarCores.Name = "menuFormatarCores";
            menuFormatarCores.Size = new Size(143, 22);
            menuFormatarCores.Text = "Cores";
            menuFormatarCores.Click += menuFormatarCores_Click;
            // 
            // menuFormatarCoresLetra
            // 
            menuFormatarCoresLetra.Name = "menuFormatarCoresLetra";
            menuFormatarCoresLetra.Size = new Size(108, 22);
            menuFormatarCoresLetra.Text = "Letra";
            menuFormatarCoresLetra.Click += menuFormatarCoresLetra_Click;
            // 
            // menuFormatarCoresFundo
            // 
            menuFormatarCoresFundo.Name = "menuFormatarCoresFundo";
            menuFormatarCoresFundo.Size = new Size(108, 22);
            menuFormatarCoresFundo.Text = "Fundo";
            menuFormatarCoresFundo.Click += menuFormatarCoresFundo_Click;
            // 
            // menuFormatarAlinhamento
            // 
            menuFormatarAlinhamento.DropDownItems.AddRange(new ToolStripItem[] { menuFormatarAlinhamentoEsquerda, menuFormatarAlinhamentoCentro, menuFormatarAlinhamentoDireita });
            menuFormatarAlinhamento.Name = "menuFormatarAlinhamento";
            menuFormatarAlinhamento.Size = new Size(143, 22);
            menuFormatarAlinhamento.Text = "Alinhamento";
            // 
            // menuFormatarAlinhamentoEsquerda
            // 
            menuFormatarAlinhamentoEsquerda.Name = "menuFormatarAlinhamentoEsquerda";
            menuFormatarAlinhamentoEsquerda.Size = new Size(122, 22);
            menuFormatarAlinhamentoEsquerda.Text = "Esquerda";
            menuFormatarAlinhamentoEsquerda.Click += menuFormatarAlinhamentoEsquerda_Click;
            // 
            // menuFormatarAlinhamentoCentro
            // 
            menuFormatarAlinhamentoCentro.Name = "menuFormatarAlinhamentoCentro";
            menuFormatarAlinhamentoCentro.Size = new Size(122, 22);
            menuFormatarAlinhamentoCentro.Text = "Centro ";
            menuFormatarAlinhamentoCentro.Click += menuFormatarAlinhamentoCentro_Click;
            // 
            // menuFormatarAlinhamentoDireita
            // 
            menuFormatarAlinhamentoDireita.Name = "menuFormatarAlinhamentoDireita";
            menuFormatarAlinhamentoDireita.Size = new Size(122, 22);
            menuFormatarAlinhamentoDireita.Text = "Direita";
            menuFormatarAlinhamentoDireita.Click += menuFormatarAlinhamentoDireita_Click;
            // 
            // rbTexto
            // 
            rbTexto.Dock = DockStyle.Fill;
            rbTexto.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            rbTexto.Location = new Point(0, 25);
            rbTexto.Name = "rbTexto";
            rbTexto.Size = new Size(800, 425);
            rbTexto.TabIndex = 1;
            rbTexto.Text = "";
            rbTexto.TextChanged += rbTexto_TextChanged;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // statusStrip1
            // 
            statusStrip1.Location = new Point(0, 428);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(800, 22);
            statusStrip1.TabIndex = 2;
            statusStrip1.Text = "statusStrip1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(statusStrip1);
            Controls.Add(rbTexto);
            Controls.Add(toolStrip1);
            Name = "Form1";
            Text = "Form1";
            WindowState = FormWindowState.Maximized;
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ToolStrip toolStrip1;
        private ToolStripSplitButton menuFicheiro;
        private ToolStripSplitButton toolStripSplitButton2;
        private ToolStripSplitButton toolStripSplitButton3;
        private ToolStripMenuItem menuFicheiroNovo;
        private ToolStripMenuItem menuFicheiroAbrir;
        private ToolStripMenuItem menuFicheiroGuardar;
        private ToolStripMenuItem menuFicheiroSair;
        private ToolStripMenuItem menuEditarCortar;
        private ToolStripMenuItem menuEditarCopiar;
        private ToolStripMenuItem menuEditarColar;
        private ToolStripMenuItem menuEditarSelecionarTudo;
        private ToolStripMenuItem menuEditarProcurar;
        private ToolStripMenuItem menuFormatarLetra;
        private ToolStripMenuItem menuFormatarCores;
        private ToolStripMenuItem menuFormatarCoresLetra;
        private ToolStripMenuItem menuFormatarCoresFundo;
        private ToolStripMenuItem menuFormatarAlinhamento;
        private ToolStripMenuItem menuFormatarAlinhamentoEsquerda;
        private ToolStripMenuItem menuFormatarAlinhamentoCentro;
        private ToolStripMenuItem menuFormatarAlinhamentoDireita;
        private RichTextBox rbTexto;
        private FontDialog fontDialog1;
        private ColorDialog colorDialog1;
        private OpenFileDialog openFileDialog1;
        private SaveFileDialog saveFileDialog1;
        private StatusStrip statusStrip1;
    }
}